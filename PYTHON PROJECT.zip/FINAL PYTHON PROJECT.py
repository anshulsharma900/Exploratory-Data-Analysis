import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the Excel file
df=pd.read_csv("C:\\Users\\LENOVO\\OneDrive\\Desktop\\python new dataset.csv")


# Clean and prepare the data
df_clean = df.copy()

# Convert relevant columns to numeric
numeric_cols = [
    "Graduate", "continuing", "dropout", "FinalCohort",
    "TransferOut", "GraduationRate"
]
df_clean[numeric_cols] = df_clean[numeric_cols].apply(pd.to_numeric, errors='coerce')

# Drop rows with missing GraduationRate
df_clean = df_clean.dropna(subset=["GraduationRate"])

# Set plot styles
sns.set(style="whitegrid")


# Objective 1: To analyze Distribution of Graduation Rates

plt.figure(figsize=(8, 5))
sns.histplot(df_clean["GraduationRate"], bins=20, color='pink')
plt.title("Distribution of Graduation Rates")
plt.xlabel("Graduation Rate")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# Objective 2: To Visualize Final Cohort vs Graduates

plt.figure(figsize=(8, 5))
sns.scatterplot(x="FinalCohort", y="Graduate", data=df_clean,hue='OrganizationLevel', palette='plasma')
plt.title("Final Cohort vs Graduates")
plt.xlabel("Final Cohort")
plt.ylabel("Number of Graduates")
plt.tight_layout()
plt.show()


# Objective 3: To show Proportion of Institutions by Organization Level
plt.figure(figsize=(8, 8))
org_counts = df_clean["OrganizationLevel"].value_counts()
colors=['lightcoral','skyblue','plum','yellowgreen']
plt.pie(org_counts, labels=org_counts.index, autopct='%1.1f%%', startangle=140,colors=colors)
plt.title("Proportion of Institutions by Organization Level")
plt.tight_layout()
plt.show()

# Objective 4: To show Top 10 Counties by Average Graduation Rate

plt.figure(figsize=(12, 6))
avg_grad_rate_county = df_clean.groupby("County")["GraduationRate"].mean().sort_values(ascending=False).head(10)
sns.barplot(x=avg_grad_rate_county.index, y=avg_grad_rate_county.values,color='salmon')
plt.title("Top 10 Counties by Average Graduation Rate")
plt.xticks(rotation=45)
plt.ylabel("Average Graduation Rate")
plt.tight_layout()
plt.show()

# Objective 5: Correlation Matrix of numeric values

plt.figure(figsize=(10, 8))
corr = df_clean[numeric_cols].corr()
sns.heatmap(corr, annot=True, cmap="YlGnBu", fmt=".2f")
plt.title("Correlation Matrix of Numeric Variables")
plt.tight_layout()
plt.show()


# Objective 6: To compare Dropout vs Continuing Students 
total_dropout = df_clean["dropout"].sum()
total_continuing = df_clean["continuing"].sum()

plt.figure(figsize=(6, 5))
sns.barplot(x=["Dropout", "Continuing"], y=[total_dropout, total_continuing])
plt.title("Total Dropout vs Continuing Students")
plt.ylabel("Number of Students")
plt.tight_layout()
plt.show()
